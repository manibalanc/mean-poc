package com.cts.optima.checkUtility.GUI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.imageio.ImageIO;
import javax.media.jai.PlanarImage;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.LineBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.cts.optima.checkUtility.DIR.DirectoryTrees;
import com.cts.optima.checkUtility.DIR.ParseXML;
import com.cts.optima.checkUtility.DOM.ImportSession;
import com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.BatchFields.BatchField;
import com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document;
import com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Codes;
import com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Codes.Code;
import com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files;
import com.cts.optima.checkUtility.LISTENER.InactivityListener;
import com.sun.media.jai.codec.ByteArraySeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.SeekableStream;

public class checkUtilityGUI {

	static DirectoryTrees t;
	private static final Logger logger = Logger.getLogger(checkUtilityGUI.class.getClass().getName());
	private JFrame frmCheckUtility;
	private JButton btnOpenFile;
	private JTree tree_1;
	private File Selection;
	private String fileWithPath;
	private String fileName;
	private JScrollPane scrollPane;
	private JTextField txtSearch;
	private JButton btnBack;
	private File nextFile;
	private String sourcePath;
	private String destinationPath;
	private String lockFile;
	JFrame frmCheckVerify;
	private ImportSession importSession;
	private JTextField txtCheckBarcode;
	private JTextField txtAuxOnUs;
	private JTextField txtEpc;
	private JTextField txtRoutingNumber;
	private JTextField txtAccount;
	private JTextField txtDollar;
	private JTextField txtMicr;
	private JTextField txtBatch;
	private JTextField txtCheckNumber;
	private JTextField txtTotal;
	List<Document> checkDataList;
	private int ptr;
	private JLabel imgFrontLbl;
	private JLabel imgRearLbl;
	private JPanel imgRearPanel;
	private JPanel imgFrontPanel;
	private ImageIcon imageFrontIcon;
	private ImageIcon imageRearIcon;
	private JLabel lblCurrent;
	private JLabel lblCount;
	HashMap<String, String> dollarList = new HashMap<String, String>();
	private String outputFile;
	private String sourceFile;
	LinkedHashMap<String, List<String>> alldocumentList = new LinkedHashMap<String, List<String>>();
	private String sessionTimeOut;
	private String selectedFolder;
	private String archievePath;
	static Handler fileHandler = null;
	private String logPath;
	private JButton btnSubmit;

	public String getLogPath() {
		return logPath;
	}

	public void setLogPath(String logPath) {
		this.logPath = logPath;
	}

	public String getArchievePath() {
		return archievePath;
	}

	public void setArchievePath(String archievePath) {
		this.archievePath = archievePath;
	}

	public String getSelectedFolder() {
		return selectedFolder;
	}

	public void setSelectedFolder(String selectedFolder) {
		this.selectedFolder = selectedFolder;
	}

	public String getSessionTimeOut() {
		return sessionTimeOut;
	}

	public void setSessionTimeOut(String sessionTimeOut) {
		this.sessionTimeOut = sessionTimeOut;
	}

	public LinkedHashMap<String, List<String>> getAlldocumentList() {
		return alldocumentList;
	}

	public void setAlldocumentList(LinkedHashMap<String, List<String>> alldocumentList) {
		this.alldocumentList = alldocumentList;
	}

	public String getSourceFile() {
		return sourceFile;
	}

	public void setSourceFile(String sourceFile) {
		this.sourceFile = sourceFile;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}

	public List<Document> getCheckDataList() {
		return checkDataList;
	}

	public void setCheckDataList(List<Document> checkDataList) {
		this.checkDataList = checkDataList;
	}

	public ImportSession getImportSession() {
		return importSession;
	}

	public void setImportSession(ImportSession importSession) {
		this.importSession = importSession;
	}

	public String getFileWithPath() {
		return fileWithPath;
	}

	public void setFileWithPath(String fileWithPath) {
		this.fileWithPath = fileWithPath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getSourcePath() {
		return sourcePath;
	}

	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}

	public String getDestinationPath() {
		return destinationPath;
	}

	public void setDestinationPath(String destinationPath) {
		this.destinationPath = destinationPath;
	}

	public String getLockFile() {
		return lockFile;
	}

	public void setLockFile(String lockFile) {
		this.lockFile = lockFile;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					setup(System.getProperty("user.dir") + "\\log\\logfile.log");
					checkUtilityGUI window = new checkUtilityGUI();
				} catch (Exception e) {
					logger.severe("Error on Main" + ExceptionUtils.getStackTrace(e));
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws IOException
	 * @wbp.parser.entryPoint
	 */
	@SuppressWarnings("unused")
	public checkUtilityGUI() throws IOException {
		String propFile = System.getProperty("user.dir") + "\\prop\\path.properties";
		String latest = null;
		File pf = new File(propFile);
		if (!pf.exists()) {
			JFrame err = new JFrame();
			logger.severe("Property file not found");
			JOptionPane.showMessageDialog(err, "Please create the property file as documented in " + propFile);
		} else {
			InputStream input = new FileInputStream(propFile);
			Properties prop = new Properties();
			prop.load(input);
			t = new DirectoryTrees(prop.getProperty("sourcePath"));
			this.setSourcePath(prop.getProperty("sourcePath"));
			this.setDestinationPath(prop.getProperty("destinationPath"));
			this.setSessionTimeOut(prop.getProperty("sessionTimeOut"));
			this.setArchievePath(prop.getProperty("archievePath"));
			logger.info("Utility launched");
			logger.info("Properties loaded " + getSourcePath() + " Destination " + getDestinationPath() + " Session "
					+ getSessionTimeOut());
			latest = selectLatestFolder(getSourcePath(), false, "");
			System.out.println("latest before " + latest);
			if (!latest.equals("No batch")) {
				if (checkForLock(latest, getSourcePath())) {
					latest = selectLatestFolder(getSourcePath(), true, latest);
				}
				logger.info("Latest batch is:::: " + latest);
				selectBatchFile(latest);
			} else {
				logger.info("No batch folders available");
				JOptionPane.showMessageDialog(frmCheckVerify, "No batch folders available");
			}

		}
		// initializeVerifyFrame(checkDataList, latest, latest, latest);

	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @param maxFile
	 */
	private void selectBatchFile(String maxFile) {

		try {
			File childrenFiles[] = new File(getSourcePath() + "//" + maxFile).listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.endsWith(".xml");
				}
			});
			fileWithPath = getSourcePath() + "\\" + maxFile + "\\" + childrenFiles[0].getName();
			fileName = FilenameUtils.getName(fileWithPath);
			Selection = new File(fileWithPath);
			System.out.println("fileWithPath:::: " + fileWithPath + "fileName:::: " + fileName);
			if (Selection.exists()) {
				if (Selection.isFile()) {
					String selected = fileWithPath.substring(0, fileWithPath.lastIndexOf('\\'));
					setSelectedFolder(selected.substring(selected.lastIndexOf('\\') + 1).trim());
					logger.info("User selected folder ::: " + getSelectedFolder());
					setLockFile(
							getSourcePath() + "\\" + getSelectedFolder() + "\\" + fileName.replace(".xml", ".lock"));
					logger.info("Lock file:::: " + getLockFile());
					File f = new File(getLockFile());
					if (f.exists() && !f.isDirectory()) {
						logger.severe("Lock file exists");
						JOptionPane.showMessageDialog(frmCheckVerify, fileName + " is currently used by another user");
					} else {
						if (!fileName.endsWith(".xml")) {
							JOptionPane.showMessageDialog(frmCheckVerify, " Please select valid XML file");
						} else {
							logger.fine("Create lock file");
							f.createNewFile();
							setOutputFile(fileWithPath.substring(fileWithPath.lastIndexOf('\\') + 1).trim());
							logger.info(" Output file name :::" + getOutputFile());
							ParseXML parsexml = new ParseXML();
							logger.info("Parsing XML " + fileWithPath);
							importSession = parsexml.ReadXml(fileWithPath);
							checkDataList = importSession.getBatches().getBatch().getDocuments().getDocument();
							logger.info("Calling check utility screen");
							initializeVerifyFrame(checkDataList, fileName, sourcePath, destinationPath);
							frmCheckVerify.setVisible(true);
						}
					}
				}

			} else {
				logger.severe("File does not exist for selection");
				JOptionPane.showMessageDialog(null, "File does not exist", "Error", JOptionPane.INFORMATION_MESSAGE);

			}

		} catch (Exception ex) {
			logger.severe("Error on parse after file selected " + ExceptionUtils.getStackTrace(ex));
		}
	}

	/**
	 * @wbp.parser.entryPoint
	 */
	public static Boolean checkForLock(String latest, String sourcePath) {
		Boolean islock = false;
		File childrenFiles[] = new File(sourcePath + "\\" + latest).listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".lock");
			}
		});
		if (childrenFiles.length > 0)
			islock = true;
		System.out.println("Is lock ::: " + islock);
		return islock;

	}

	/**
	 * @wbp.parser.entryPoint
	 */
	public static String selectLatestFolder(String folderPath, Boolean lock, String lockFolder) {
		File latestFolder = null;
		File dir = new File(folderPath);
		File[] nonLockDirs = null;
		String recent = null;
		if (lock) {
			nonLockDirs = dir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					return file.isDirectory() && !file.getName().equalsIgnoreCase(lockFolder);
				}
			});
		} else {
			nonLockDirs = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File file) {
					return file.isDirectory();
				}
			});
		}

		for (

		File file : nonLockDirs) {
			if (file.isDirectory() && (latestFolder == null || latestFolder.lastModified() > file.lastModified())) {

				latestFolder = file;
			}
		}
		if (nonLockDirs.length > 0) {
			recent = latestFolder.getName();
		} else {
			recent = "No batch";
		}
		return recent;
	}

	/**
	 * @throws Exception
	 * @wbp.parser.entryPoint
	 */
	private void initializeVerifyFrame(List<Document> checkDocumentData, String fileName, String sourcePath,
			String destinationPath) throws Exception {
		logger.info("Launching check utility screen");
		frmCheckVerify = new JFrame();
		frmCheckVerify.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				frmCheckVerify.setVisible(false);
				frmCheckVerify.repaint();
				dollarList.clear();
				File f = new File(getLockFile());
				logger.info("User closed the window deleting lock file:::: " + getLockFile());
				f.delete();
			}
		});

		Action logout = new AbstractAction() {
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				JOptionPane.showOptionDialog(null, "You're being timed out due to inactivity.", "Session Timed Out",
						JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
				frmCheckVerify.repaint();
				dollarList.clear();
				File f = new File(getLockFile());
				logger.info("User is idle for " + getSessionTimeOut() + " minutes deleting lock file :::: "
						+ getLockFile());
				f.delete();
			}
		};

		InactivityListener listener = new InactivityListener(frmCheckVerify, logout,
				Integer.parseInt(getSessionTimeOut()));
		listener.start();
		logger.info("Inactive listener started");
		frmCheckVerify.getContentPane().setBackground(new Color(135, 206, 250));
		frmCheckVerify.setBackground(new Color(135, 206, 250));
		frmCheckVerify.setTitle("CHECK UTILITY");
		frmCheckVerify.setBounds(100, 100, 1361, 737);
		frmCheckVerify.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCheckVerify.getContentPane().setLayout(null);

		frmCheckVerify.getContentPane().setBackground(new Color(135, 206, 250));
		frmCheckVerify.getContentPane().setLayout(null);
		frmCheckVerify.setExtendedState(JFrame.MAXIMIZED_BOTH);

		JLabel lblCheckDetails = new JLabel("CHECK DETAILS");
		lblCheckDetails.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCheckDetails.setBounds(28, 256, 146, 20);
		frmCheckVerify.getContentPane().add(lblCheckDetails);

		JLabel lblcheckbarcode = new JLabel("Check Barcode #");
		lblcheckbarcode.setBounds(28, 292, 146, 20);
		frmCheckVerify.getContentPane().add(lblcheckbarcode);

		txtCheckBarcode = new JTextField();
		txtCheckBarcode.setEditable(true);
		txtCheckBarcode.setBounds(28, 328, 146, 26);
		frmCheckVerify.getContentPane().add(txtCheckBarcode);
		txtCheckBarcode.setColumns(10);

		JLabel lblAuxOn = new JLabel("Aux - On - Us");
		lblAuxOn.setBounds(220, 292, 142, 20);
		frmCheckVerify.getContentPane().add(lblAuxOn);

		txtAuxOnUs = new JTextField();
		txtAuxOnUs.setEditable(true);
		txtAuxOnUs.setBounds(219, 328, 146, 26);
		frmCheckVerify.getContentPane().add(txtAuxOnUs);
		txtAuxOnUs.setColumns(10);

		JLabel lblEpc = new JLabel("EPC");
		lblEpc.setBounds(28, 374, 69, 20);
		frmCheckVerify.getContentPane().add(lblEpc);

		txtEpc = new JTextField();
		txtEpc.setEditable(true);
		txtEpc.setColumns(10);
		txtEpc.setBounds(28, 410, 146, 26);
		frmCheckVerify.getContentPane().add(txtEpc);

		JLabel lblRoutingNumber = new JLabel("Routing Number");
		lblRoutingNumber.setBounds(220, 374, 142, 20);
		frmCheckVerify.getContentPane().add(lblRoutingNumber);

		txtRoutingNumber = new JTextField();
		txtRoutingNumber.setEditable(true);
		txtRoutingNumber.setColumns(10);
		txtRoutingNumber.setBounds(219, 410, 146, 26);
		frmCheckVerify.getContentPane().add(txtRoutingNumber);

		JLabel lblAccount = new JLabel("Account # / On - Us");
		lblAccount.setBounds(28, 451, 177, 20);
		frmCheckVerify.getContentPane().add(lblAccount);

		txtAccount = new JTextField();
		txtAccount.setEditable(true);
		txtAccount.setColumns(10);
		txtAccount.setBounds(28, 487, 146, 26);
		frmCheckVerify.getContentPane().add(txtAccount);

		txtMicr = new JTextField();
		txtMicr.setEditable(false);
		txtMicr.setColumns(10);
		txtMicr.setBounds(28, 487, 146, 26);
		txtMicr.setVisible(false);
		frmCheckVerify.getContentPane().add(txtMicr);

		ptr = 0;
		Document checkDocument = checkDocumentData.get(ptr);
		Files filesTag = checkDocument.getFiles().get(0);
		com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileFrontImageTag = filesTag
				.getFile().get(0);
		com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileRearImageTag = filesTag
				.getFile().get(1);
		Codes codeBarcodeTag = checkDocument.getCodes().get(0);
		Code codeBarcode = codeBarcodeTag.getCode().get(0);
		Code codeMicr = codeBarcodeTag.getCode().get(1);
		BatchField bat = importSession.getBatches().batch.getBatchFields().getBatchField().get(2);
		JLabel lblDollarAmount = new JLabel("Dollar Amount");
		lblDollarAmount.setBounds(48, 539, 142, 20);
		frmCheckVerify.getContentPane().add(lblDollarAmount);

		txtDollar = new JTextField();
		txtDollar.setToolTipText("Enter amount in 0.00 format");
		txtDollar.setColumns(10);
		txtDollar.setBounds(192, 536, 146, 26);
		txtDollar.requestFocusInWindow();
		frmCheckVerify.getContentPane().add(txtDollar);
		// PlainDocument plaindoc = (PlainDocument) txtDollar.getDocument();
		// plaindoc.setDocumentFilter(new FloatFilter());

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(51, 153, 255)));
		panel.setBackground(new Color(135, 206, 250));
		panel.setBounds(15, 242, 371, 281);
		frmCheckVerify.getContentPane().add(panel);

		JLabel lblBatchDetails = new JLabel("BATCH DETAILS");
		lblBatchDetails.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBatchDetails.setBounds(25, 35, 149, 20);
		frmCheckVerify.getContentPane().add(lblBatchDetails);

		JLabel lblNewLabel_3 = new JLabel("Batch #");
		lblNewLabel_3.setBounds(25, 71, 69, 20);
		frmCheckVerify.getContentPane().add(lblNewLabel_3);

		txtBatch = new JTextField();
		txtBatch.setEditable(false);
		txtBatch.setColumns(10);
		txtBatch.setBounds(25, 107, 146, 26);
		frmCheckVerify.getContentPane().add(txtBatch);

		JLabel lblCheckIn = new JLabel("Check # in Batch");
		lblCheckIn.setBounds(217, 71, 134, 20);
		frmCheckVerify.getContentPane().add(lblCheckIn);

		txtCheckNumber = new JTextField();
		txtCheckNumber.setEditable(false);
		txtCheckNumber.setColumns(10);
		txtCheckNumber.setBounds(216, 107, 146, 26);
		frmCheckVerify.getContentPane().add(txtCheckNumber);

		JLabel lblNewLabel_1_1 = new JLabel("Total Balance");
		lblNewLabel_1_1.setBounds(25, 153, 69, 20);
		frmCheckVerify.getContentPane().add(lblNewLabel_1_1);

		txtTotal = new JTextField();
		txtTotal.setEditable(false);
		txtTotal.setColumns(10);
		txtTotal.setBounds(25, 189, 146, 26);
		frmCheckVerify.getContentPane().add(txtTotal);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 153, 255), 1, true));
		panel_1.setBackground(new Color(135, 206, 250));
		panel_1.setBounds(15, 28, 371, 198);

		frmCheckVerify.getContentPane().add(panel_1);
		imgFrontPanel = new JPanel();
		imgFrontPanel.setBorder(null);
		imgFrontPanel.setBackground(new Color(135, 206, 250));
		imgFrontPanel.setBounds(390, 15, 900, 315);
		frmCheckVerify.getContentPane().add(imgFrontPanel);
		logger.info("Image path " + sourcePath + "\\" + getSelectedFolder() + "\\" + fileFrontImageTag.getFilename());

		FileInputStream inFront = new FileInputStream(
				sourcePath + "\\" + getSelectedFolder() + "\\" + fileFrontImageTag.getFilename());
		FileChannel channel = inFront.getChannel();
		ByteBuffer bufferFront = ByteBuffer.allocate((int) channel.size());
		channel.read(bufferFront);
		Image imageFront = load(bufferFront.array());

		FileInputStream inRear = new FileInputStream(
				sourcePath + "\\" + getSelectedFolder() + "\\" + fileRearImageTag.getFilename());
		FileChannel channelRear = inRear.getChannel();
		ByteBuffer bufferRear = ByteBuffer.allocate((int) channelRear.size());
		channelRear.read(bufferRear);
		Image imageRear = load(bufferRear.array());

		imageFrontIcon = new ImageIcon(new ImageIcon(imageFront).getImage().getScaledInstance(imgFrontPanel.getWidth(),
				imgFrontPanel.getHeight(), Image.SCALE_DEFAULT));
		imgFrontLbl = new JLabel("");
		imgFrontLbl.setIcon(imageFrontIcon);
		imgFrontLbl.setBounds(390, 15, imgFrontPanel.getWidth(), imgFrontPanel.getHeight());
		imgFrontPanel.add(imgFrontLbl);

		imgRearPanel = new JPanel();
		imgRearPanel.setBorder(null);
		imgRearPanel.setBackground(new Color(135, 206, 250));
		imgRearPanel.setBounds(390, 337, 900, 315);
		frmCheckVerify.getContentPane().add(imgRearPanel);
		imageRearIcon = new ImageIcon(new ImageIcon(imageRear).getImage().getScaledInstance(imgRearPanel.getWidth(),
				imgRearPanel.getHeight(), Image.SCALE_DEFAULT));
		imgRearLbl = new JLabel("");
		imgRearLbl.setIcon(imageRearIcon);
		imgRearLbl.setBounds(438, 345, imgRearPanel.getWidth(), imgRearPanel.getHeight());
		imgRearPanel.add(imgRearLbl);

		txtCheckBarcode.setText(codeBarcode.getBarcode());
		txtRoutingNumber.setText(StringUtils.substringBetween(codeMicr.getMICR(), ":", ":"));
		if (StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0) == '4') {
			txtEpc.setText(String.valueOf(StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0)));
		}
		String auxOn = codeMicr.getMICR().substring(codeMicr.getMICR().lastIndexOf(':') + 1).trim();
		auxOn = auxOn.replace("<", "/");
		auxOn = auxOn.replace("=", "-");
		txtAccount.setText(auxOn);
		txtBatch.setText(bat.getValueAttribute());
		txtCheckNumber.setText("1");
		txtMicr.setText(codeMicr.getMICR());
		inFront.close();
		inRear.close();
		/*
		 * List<String> singleDocumentList = new ArrayList<String>();
		 * singleDocumentList.add(txtRoutingNumber.getText());
		 * singleDocumentList.add(txtEpc.getText());
		 * singleDocumentList.add(txtAccount.getText());
		 * singleDocumentList.add(txtAuxOnUs.getText());
		 * alldocumentList.put(codeBarcode.getBarcode(), singleDocumentList);
		 */
		JButton btnPrevious = new JButton("PREV");
		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtDollar.requestFocusInWindow();
				boolean error = false;
				List<String> errors = new ArrayList<String>();
				if (txtDollar.getText().equals("")) {
					error = true;
					errors.add("Please enter dollar amount.");
				}
				if (txtCheckBarcode.getText().equals("")) {
					error = true;
					errors.add("Please enter check barcode.");
				}
				if (txtRoutingNumber.getText().equals("")) {
					error = true;
					errors.add("Please enter routing number.");
				}
				if (txtAccount.getText().equals("")) {
					error = true;
					errors.add("Please enter account number.");
				}
				if (!txtDollar.getText().equals("") && !txtDollar.getText().matches("^[0-9]+[.]+[0-9]{0,2}$")) {
					error = true;
					errors.add("Invalid dollar amount.");
				}
				if (error) {
					String errorList = "Following error occured";
					for (String err : errors) {
						System.out.println(err);
						errorList += System.getProperty("line.separator") + err;
					}
					JOptionPane.showMessageDialog(frmCheckVerify, errorList);
				} else {
					dollarList.put("item" + ptr, txtDollar.getText());
					double c = 0;
					if (!txtDollar.getText().equals("")) {
						for (Map.Entry<String, String> entry : dollarList.entrySet()) {
							String k = entry.getKey();
							String v = entry.getValue();
							if (v.matches("^[0-9]+[.]?[0-9]{0,2}$")) {
								c += Double.parseDouble(v);
							}
						}
					}
					txtTotal.setText(String.format("%.2f", c));
					List<String> singleDocumentListnext = new ArrayList<String>();
					singleDocumentListnext.add(txtRoutingNumber.getText());
					singleDocumentListnext.add(txtEpc.getText());
					singleDocumentListnext.add(txtAccount.getText());
					singleDocumentListnext.add(txtAuxOnUs.getText());
					singleDocumentListnext.add(txtCheckBarcode.getText());
					singleDocumentListnext.add(txtMicr.getText());
					singleDocumentListnext.add(txtDollar.getText());
					alldocumentList.put("item" + ptr, singleDocumentListnext);
					System.out.println(alldocumentList);
				}
				if (ptr > 0) {
					ptr--;
					lblCurrent.setText(Integer.toString(ptr + 1));
					Document checkDocument = checkDocumentData.get(ptr);
					Files filesTag = checkDocument.getFiles().get(0);
					com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileFrontImageTag = filesTag
							.getFile().get(0);
					com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileRearImageTag = filesTag
							.getFile().get(1);
					Codes codeBarcodeTag = checkDocument.getCodes().get(0);
					Code codeBarcode = codeBarcodeTag.getCode().get(0);
					Code codeMicr = codeBarcodeTag.getCode().get(1);
					try {
						FileInputStream inFront = new FileInputStream(
								sourcePath + "\\" + getSelectedFolder() + "\\" + fileFrontImageTag.getFilename());
						FileChannel channel = inFront.getChannel();
						ByteBuffer bufferFront = ByteBuffer.allocate((int) channel.size());
						channel.read(bufferFront);
						Image imageFront = load(bufferFront.array());

						FileInputStream inRear = new FileInputStream(
								sourcePath + "\\" + getSelectedFolder() + "\\" + fileRearImageTag.getFilename());
						FileChannel channelRear = inRear.getChannel();
						ByteBuffer bufferRear = ByteBuffer.allocate((int) channelRear.size());
						channelRear.read(bufferRear);
						Image imageRear = load(bufferRear.array());

						imgFrontLbl.setIcon(new ImageIcon(new ImageIcon(imageFront).getImage().getScaledInstance(
								imgFrontPanel.getWidth(), imgFrontPanel.getHeight(), Image.SCALE_DEFAULT)));
						imgRearLbl.setIcon(new ImageIcon(new ImageIcon(imageRear).getImage().getScaledInstance(
								imgRearPanel.getWidth(), imgRearPanel.getHeight(), Image.SCALE_DEFAULT)));
						System.out.println("previous ptr ::: item" + ptr);
						if (alldocumentList.containsKey("item" + ptr)) {
							txtCheckBarcode.setText(alldocumentList.get("item" + ptr).get(4));
							txtDollar.setText(alldocumentList.get("item" + ptr).get(6));
							txtRoutingNumber.setText(alldocumentList.get("item" + ptr).get(0));
							txtEpc.setText(alldocumentList.get("item" + ptr).get(1));
							txtAccount.setText(alldocumentList.get("item" + ptr).get(2));
						} else {
							txtCheckBarcode.setText(codeBarcode.getBarcode());
							txtDollar.setText(dollarList.get(codeBarcode.getBarcode()));
							txtRoutingNumber.setText(StringUtils.substringBetween(codeMicr.getMICR(), ":", ":"));
							if (StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0) == '4') {
								txtEpc.setText(String
										.valueOf(StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0)));
							}
							txtAuxOnUs.setText("");
							String auxOn = codeMicr.getMICR().substring(codeMicr.getMICR().lastIndexOf(':') + 1).trim();
							auxOn = auxOn.replace("<", "/");
							auxOn = auxOn.replace("=", "-");
							txtAccount.setText(auxOn);
						}
						txtCheckNumber.setText(Integer.toString(ptr + 1));
						txtMicr.setText(codeMicr.getMICR());
						inFront.close();
						inRear.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});

		btnPrevious.setBounds(19, 593, 115, 29);
		frmCheckVerify.getContentPane().add(btnPrevious);

		JButton btnNext = new JButton("NEXT");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("sadsadsadsadsadsadsadsa");
				txtDollar.requestFocusInWindow();
				boolean error = false;
				List<String> errors = new ArrayList<String>();
				if (txtDollar.getText().equals("")) {
					error = true;
					errors.add("Please enter dollar amount.");
				}
				if (txtCheckBarcode.getText().equals("")) {
					error = true;
					errors.add("Please enter check barcode.");
				}
				if (txtRoutingNumber.getText().equals("")) {
					error = true;
					errors.add("Please enter routing number.");
				}
				if (txtAccount.getText().equals("")) {
					error = true;
					errors.add("Please enter account number.");
				}
				if (!txtDollar.getText().equals("") && !txtDollar.getText().matches("^[0-9]+[.]+[0-9]{0,2}$")) {
					error = true;
					errors.add("Invalid dollar amount.");
				} 
				System.out.println("_____________" + error);
				if (error) {
					String errorList = "Following error occured";
					for (String err : errors) {
						System.out.println(err);
						errorList += System.getProperty("line.separator") + err;
					}
					JOptionPane.showMessageDialog(frmCheckVerify, errorList);
				} else {
					dollarList.put("item" + ptr, txtDollar.getText());
					double c = 0;
					if (!txtDollar.getText().equals("")) {
						for (Map.Entry<String, String> entry : dollarList.entrySet()) {
							String k = entry.getKey();
							String v = entry.getValue();
							if (v.matches("^[0-9]+[.]?[0-9]{0,2}$")) {
								c += Double.parseDouble(v);
							}
						}
					}
					txtTotal.setText(String.format("%.2f", c));
					List<String> singleDocumentListnext = new ArrayList<String>();
					singleDocumentListnext.add(txtRoutingNumber.getText());
					singleDocumentListnext.add(txtEpc.getText());
					singleDocumentListnext.add(txtAccount.getText());
					singleDocumentListnext.add(txtAuxOnUs.getText());
					singleDocumentListnext.add(txtCheckBarcode.getText());
					singleDocumentListnext.add(txtMicr.getText());
					singleDocumentListnext.add(txtDollar.getText());
					alldocumentList.put("item" + ptr, singleDocumentListnext);
					System.out.println("all docs" + alldocumentList);
					System.out.println("check docs" + checkDataList);
					System.out.println("all::: "+ alldocumentList.size() + " ==== " + checkDataList.size());
					if (alldocumentList.size() == checkDataList.size()) {
						btnSubmit.setEnabled(true);
					}
					if (ptr < (checkDataList.size() - 1)) { // lists are 0 based
						ptr++;
						lblCurrent.setText(Integer.toString(ptr + 1));
						Document checkDocument = checkDocumentData.get(ptr);
						Files filesTag = checkDocument.getFiles().get(0);
						com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileFrontImageTag = filesTag
								.getFile().get(0);
						com.cts.optima.checkUtility.DOM.ImportSession.Batches.Batch.Documents.Document.Files.File fileRearImageTag = filesTag
								.getFile().get(1);
						Codes codeBarcodeTag = checkDocument.getCodes().get(0);
						Code codeBarcode = codeBarcodeTag.getCode().get(0);
						Code codeMicr = codeBarcodeTag.getCode().get(1);

						
						try {
							System.out.println("Inside Next");
							System.out.println("-------" + sourcePath + "\\" + getSelectedFolder() + "\\" + fileFrontImageTag.getFilename());
							FileInputStream inFront = new FileInputStream(
									sourcePath + "\\" + getSelectedFolder() + "\\" + fileFrontImageTag.getFilename());
							FileChannel channel = inFront.getChannel();
							ByteBuffer bufferFront = ByteBuffer.allocate((int) channel.size());
							channel.read(bufferFront);
							Image imageFront = load(bufferFront.array());

							FileInputStream inRear = new FileInputStream(
									sourcePath + "\\" + getSelectedFolder() + "\\" + fileRearImageTag.getFilename());
							FileChannel channelRear = inRear.getChannel();
							ByteBuffer bufferRear = ByteBuffer.allocate((int) channelRear.size());
							channelRear.read(bufferRear);
							Image imageRear = load(bufferRear.array());

							imgFrontLbl.setIcon(new ImageIcon(new ImageIcon(imageFront).getImage().getScaledInstance(
									imgFrontPanel.getWidth(), imgFrontPanel.getHeight(), Image.SCALE_DEFAULT)));
							imgRearLbl.setIcon(new ImageIcon(new ImageIcon(imageRear).getImage().getScaledInstance(
									imgRearPanel.getWidth(), imgRearPanel.getHeight(), Image.SCALE_DEFAULT)));
							System.out.println("next ptr ::: item" + ptr);
							if (alldocumentList.containsKey("item" + ptr)) {
								txtCheckBarcode.setText(alldocumentList.get("item" + ptr).get(4));
								txtDollar.setText(alldocumentList.get("item" + ptr).get(6));
								txtRoutingNumber.setText(alldocumentList.get("item" + ptr).get(0));
								txtEpc.setText(alldocumentList.get("item" + ptr).get(1));
								txtAccount.setText(alldocumentList.get("item" + ptr).get(2));
							} else {
								txtCheckBarcode.setText(codeBarcode.getBarcode());
								txtDollar.setText(dollarList.get(codeBarcode.getBarcode()));
								txtRoutingNumber.setText(StringUtils.substringBetween(codeMicr.getMICR(), ":", ":"));
								if (StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0) == '4') {
									txtEpc.setText(String.valueOf(
											StringUtils.substringBetween(codeMicr.getMICR(), ":", ":").charAt(0)));
								}
								txtAuxOnUs.setText("");
								String auxOn = codeMicr.getMICR().substring(codeMicr.getMICR().lastIndexOf(':') + 1)
										.trim();
								auxOn = auxOn.replace("<", "/");
								auxOn = auxOn.replace("=", "-");
								txtAccount.setText(auxOn);
							}
							txtCheckNumber.setText(Integer.toString(ptr + 1));
							txtMicr.setText(codeMicr.getMICR());
							inRear.close();
							inFront.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		});

		btnNext.setBounds(141, 593, 115, 29);
		frmCheckVerify.getContentPane().add(btnNext);

		btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			@SuppressWarnings("unlikely-arg-type")
			public void actionPerformed(ActionEvent arg0) {
				logger.info("User clicked submit button");
				logger.info("Amount entered " + dollarList.toString());
				logger.info("Parsed documents " + alldocumentList);
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder;
				try {
					File f = new File(getLockFile());
					String outputXML = destinationPath + "\\" + selectedFolder + "\\" + outputFile;
					logger.info("Generating Output " + outputXML);
					logger.info("Deleting lock file after output generated " + getLockFile());
					f.delete();
					FileUtils.copyDirectory(new File(sourcePath + "\\" + selectedFolder),
							new File(destinationPath + "\\" + selectedFolder));
					docBuilder = docFactory.newDocumentBuilder();
					org.w3c.dom.Document doc = docBuilder.parse(outputXML);

					Node batchFields = doc.getElementsByTagName("BatchFields").item(0);

					Element batchNumber = doc.createElement("BatchField");
					batchNumber.setAttribute("Name", "Batch Name");
					batchNumber.setAttribute("Value", txtBatch.getText());
					batchFields.appendChild(batchNumber);

					Element checksInBatch = doc.createElement("BatchField");
					checksInBatch.setAttribute("Name", "Checks In Batch");
					checksInBatch.setAttribute("Value", lblCount.getText());
					batchFields.appendChild(checksInBatch);

					Element totalBalance = doc.createElement("BatchField");
					totalBalance.setAttribute("Name", "Total Balance");
					totalBalance.setAttribute("Value", txtTotal.getText());
					batchFields.appendChild(totalBalance);

					int i = 0;
					for (String key : alldocumentList.keySet()) {
						Node code = doc.getElementsByTagName("Codes").item(i);

						NodeList nList = doc.getElementsByTagName("Code");
						for (int i1 = 0; i1 < nList.getLength(); i1++) {
							Node node = nList.item(i1);
							if (node.getNodeType() == Element.ELEMENT_NODE) {
								Element eElement = (Element) node;
								if (eElement.hasAttribute("Barcode")) {
									node.getParentNode().removeChild(node);
								}
								if (eElement.hasAttribute("MICR")) {
									node.getParentNode().removeChild(node);
								}
							}
						}

						Element barcode = doc.createElement("Code");
						barcode.setAttribute("Name", "Barcode");
						barcode.setAttribute("Value", alldocumentList.get(key).get(4));
						code.appendChild(barcode);

						Element micr = doc.createElement("Code");
						micr.setAttribute("Name", "MICR");
						micr.setAttribute("Value", alldocumentList.get(key).get(5));
						code.appendChild(micr);

						Element aux = doc.createElement("Code");
						aux.setAttribute("Name", "Aux-On-Us");
						aux.setAttribute("Value", alldocumentList.get(key).get(3));
						code.appendChild(aux);

						Element epc = doc.createElement("Code");
						epc.setAttribute("Name", "EPC");
						epc.setAttribute("Value", alldocumentList.get(key).get(1));
						code.appendChild(epc);

						Element dollar = doc.createElement("Code");
						dollar.setAttribute("Name", "Dollar Amount");
						dollar.setAttribute("Value", dollarList.get(key));
						code.appendChild(dollar);

						Element routing = doc.createElement("Code");
						routing.setAttribute("Name", "Routing Number");
						routing.setAttribute("Value", alldocumentList.get(key).get(0));
						code.appendChild(routing);

						Element account = doc.createElement("Code");
						account.setAttribute("Name", "Account Number");
						account.setAttribute("Value", alldocumentList.get(key).get(2));
						code.appendChild(account);
						i++;
					}

					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					transformerFactory.setAttribute("indent-number", new Integer(2));
					Transformer transformer = transformerFactory.newTransformer();
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					DOMSource source = new DOMSource(doc);
					StreamResult result = new StreamResult(new java.io.File(outputXML));
					transformer.transform(source, result);
					FileUtils.deleteDirectory(new File(archievePath + "\\" + selectedFolder));
					FileUtils.moveDirectory(new File(sourcePath + "\\" + selectedFolder),
							new File(archievePath + "\\" + selectedFolder));
					logger.info("Output generated " + outputXML);
					JOptionPane.showMessageDialog(frmCheckVerify, txtBatch.getText() + " completed successfully");
					logger.info("Opening utility for next batch");
					frmCheckVerify.setVisible(false);
					checkUtilityGUI window = new checkUtilityGUI();

				} catch (ParserConfigurationException pce) {
					logger.severe("Error on ParserConfiguration" + ExceptionUtils.getStackTrace(pce));
				} catch (IOException ioe) {
					logger.severe("Error on IO" + ExceptionUtils.getStackTrace(ioe));
				} catch (SAXException sae) {
					logger.severe("Error on SAX" + ExceptionUtils.getStackTrace(sae));
				} catch (TransformerConfigurationException tce) {
					logger.severe("Error on TransformerConfiguration" + ExceptionUtils.getStackTrace(tce));
				} catch (TransformerException te) {
					logger.severe("Error on Transformer" + ExceptionUtils.getStackTrace(te));
				}
			}
		});
		btnSubmit.setEnabled(false);
		btnSubmit.setBounds(271, 593, 115, 29);
		frmCheckVerify.getContentPane().add(btnSubmit);

		lblCurrent = new JLabel();
		lblCurrent.setBounds(151, 632, 28, 20);
		frmCheckVerify.getContentPane().add(lblCurrent);
		lblCurrent.setText("1");

		JLabel lblOf = new JLabel("of");
		lblOf.setBounds(189, 632, 21, 20);
		frmCheckVerify.getContentPane().add(lblOf);

		lblCount = new JLabel();
		lblCount.setBounds(218, 632, 28, 20);
		frmCheckVerify.getContentPane().add(lblCount);
		lblCount.setText(Integer.toString(checkDocumentData.size()));

	}

	public File getNextFile() {
		return nextFile;
	}

	public void setNextFile(File nextFile) {
		this.nextFile = nextFile;
	}

	public int getPtr() {
		return ptr;
	}

	public void setPtr(int ptr) {
		this.ptr = ptr;
	}

	/**
	 * @wbp.parser.entryPoint
	 */
	public static void setup(String logFilePath) {

		try {
			System.out.println(logFilePath);
			fileHandler = new FileHandler(logFilePath, true);// file
			SimpleFormatter simple = new SimpleFormatter();
			fileHandler.setFormatter(simple);
			logger.addHandler(fileHandler);// adding Handler for file
			logger.info("Log file path " + logFilePath);

		} catch (IOException e) {
			// TODO Auto-generated catch block
		}

	}

	static Image load(byte[] data) throws Exception {
		Image image = null;
		SeekableStream stream = new ByteArraySeekableStream(data);
		String[] names = ImageCodec.getDecoderNames(stream);
		ImageDecoder dec = ImageCodec.createImageDecoder(names[0], stream, null);
		RenderedImage im = dec.decodeAsRenderedImage();
		image = PlanarImage.wrapRenderedImage(im).getAsBufferedImage();
		return image;
	}

}
