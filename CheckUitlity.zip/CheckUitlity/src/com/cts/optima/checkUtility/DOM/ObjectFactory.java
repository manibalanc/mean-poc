package com.cts.optima.checkUtility.DOM;

import javax.xml.bind.annotation.XmlRegistry;



@XmlRegistry
public class ObjectFactory {


    public ObjectFactory() {
    }

    public ImportSession createImportSession() {
        return new ImportSession();
    }

    public ImportSession.Batches createImportSessionBatches() {
        return new ImportSession.Batches();
    }

    public ImportSession.Batches.Batch createImportSessionBatchesBatch() {
        return new ImportSession.Batches.Batch();
    }

    public ImportSession.Batches.Batch.Documents createImportSessionBatchesBatchDocuments() {
        return new ImportSession.Batches.Batch.Documents();
    }

    public ImportSession.Batches.Batch.Documents.Document createImportSessionBatchesBatchDocumentsDocument() {
        return new ImportSession.Batches.Batch.Documents.Document();
    }

    public ImportSession.Batches.Batch.Documents.Document.Codes createImportSessionBatchesBatchDocumentsDocumentCodes() {
        return new ImportSession.Batches.Batch.Documents.Document.Codes();
    }

    public ImportSession.Batches.Batch.Documents.Document.Files createImportSessionBatchesBatchDocumentsDocumentFiles() {
        return new ImportSession.Batches.Batch.Documents.Document.Files();
    }

    public ImportSession.Batches.Batch.BatchFields createImportSessionBatchesBatchBatchFields() {
        return new ImportSession.Batches.Batch.BatchFields();
    }

    public ImportSession.Batches.Batch.Documents.Document.Codes.Code createImportSessionBatchesBatchDocumentsDocumentCodesCode() {
        return new ImportSession.Batches.Batch.Documents.Document.Codes.Code();
    }

    public ImportSession.Batches.Batch.Documents.Document.Files.File createImportSessionBatchesBatchDocumentsDocumentFilesFile() {
        return new ImportSession.Batches.Batch.Documents.Document.Files.File();
    }

    public ImportSession.Batches.Batch.BatchFields.BatchField createImportSessionBatchesBatchBatchFieldsBatchField() {
        return new ImportSession.Batches.Batch.BatchFields.BatchField();
    }

}
