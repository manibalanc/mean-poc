package com.cts.optima.checkUtility.DIR;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.cts.optima.checkUtility.DOM.ImportSession;

public class ParseXML {

	public ImportSession ReadXml(String fileName) throws JAXBException {

		System.out.println("parsing file::: " + fileName);
		JAXBContext jc = JAXBContext.newInstance(ImportSession.class);

		Unmarshaller unmarshaller = jc.createUnmarshaller();
		ImportSession importSession = (ImportSession) unmarshaller.unmarshal(new File(fileName));

		return importSession;
		// }
	}
}
