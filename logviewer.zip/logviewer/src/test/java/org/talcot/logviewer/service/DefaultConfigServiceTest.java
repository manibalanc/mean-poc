package org.talcot.logviewer.service;

import static org.junit.Assert.*;

import javax.xml.bind.JAXBContext;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.talcot.logviewer.bean.LogViewerConfig;
import org.talcot.logviewer.exception.ConfigException;
import org.talcot.logviewer.service.DefaultConfigService;


public class DefaultConfigServiceTest {
	
	private DefaultConfigService configService = new DefaultConfigService();
	
	@Before
	public void setup() throws Exception {
		configService.logViewerConfigJaxbContext = JAXBContext.newInstance(LogViewerConfig.class);
	}

	@Test
	public void reloadLogViewerConfigIfNecessary_OK() {
		
		// Init data
		configService.logViewerConfigResource = new ClassPathResource("logviewer.xml");

		// Execute test
		configService.reloadLogViewerConfigIfNecessary();

		// Assertions
		assertNotNull(configService.logAccessConfigs);
		assertFalse(configService.logAccessConfigs.isEmpty());
	}

	@Test(expected=ConfigException.class)
	public void reloadLogViewerConfigIfNecessary_ConfigNotFound() {
		configService.logViewerConfigResource = new ClassPathResource("logviewer-unfound.xml");
		configService.reloadLogViewerConfigIfNecessary();
	}
	
	@Test(expected=ConfigException.class)
	public void reloadLogViewerConfigIfNecessary_InvalidOptionsInConfig() {
		configService.logViewerConfigResource = new ClassPathResource("logviewer-invalid-ssh.xml");
		configService.reloadLogViewerConfigIfNecessary();
	}
	
	@Test(expected=ConfigException.class)
	public void reloadLogViewerConfigIfNecessary_InvalidTypeInConfig() {
		configService.logViewerConfigResource = new ClassPathResource("logviewer-invalid-type.xml");
		configService.reloadLogViewerConfigIfNecessary();
	}
	
}
