package org.talcot.logviewer.bean;

import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;

import org.junit.Test;
import org.talcot.logviewer.bean.LogAccessConfig;
import org.talcot.logviewer.bean.LogViewerConfig;
import org.talcot.logviewer.bean.LogAccessConfig.LogAccessType;

import static org.junit.Assert.*;



public class LogViewerConfigTest {

	@Test
	public void testXmlMarshalling() throws Exception {
		
		// Create jaxb data
		LogViewerConfig logViewerConfig = new LogViewerConfig();
		logViewerConfig.getLogAccessConfigs().add(new LogAccessConfig("log-access1", LogAccessType.LOCAL, "localhost", "/logs", "Fabien"));
		logViewerConfig.getLogAccessConfigs().add(new LogAccessConfig("log-access2", LogAccessType.LOCAL, "localhost", "/logs", "Fabien"));
		
		// Marshall to xml
		JAXBContext jaxbContext = JAXBContext.newInstance(LogViewerConfig.class);
		StringWriter xmlOutput = new StringWriter();
		jaxbContext.createMarshaller().marshal(logViewerConfig, xmlOutput);
		System.out.println(xmlOutput);
		
		// Assertions
		String expectedXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><logviewer-config><log-access-config id=\"log-access1\" type=\"LOCAL\" user=\"Fabien\" host=\"localhost\" directory=\"/logs\" authorized-users=\"*\" authorized-roles=\"*\" trust=\"false\"/><log-access-config id=\"log-access2\" type=\"LOCAL\" user=\"Fabien\" host=\"localhost\" directory=\"/logs\" authorized-users=\"*\" authorized-roles=\"*\" trust=\"false\"/></logviewer-config>";
		if (System.getProperty("java.version").startsWith("1.6.")) {
			expectedXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><logviewer-config><log-access-config trust=\"false\" authorized-roles=\"*\" authorized-users=\"*\" directory=\"/logs\" host=\"localhost\" user=\"Fabien\" type=\"LOCAL\" id=\"log-access1\"/><log-access-config trust=\"false\" authorized-roles=\"*\" authorized-users=\"*\" directory=\"/logs\" host=\"localhost\" user=\"Fabien\" type=\"LOCAL\" id=\"log-access2\"/></logviewer-config>";
		}
		assertEquals(expectedXml, xmlOutput.toString());
	}

	@Test
	public void testXmlUnmarshalling() throws Exception {
		
		// Get XML stream
		InputStream xmlInputStream = getClass().getResourceAsStream("/logviewer-with-authorized-users.xml");
		
		// Unmarshall to bean
		JAXBContext jaxbContext = JAXBContext.newInstance(LogViewerConfig.class);
		LogViewerConfig logViewerConfig = (LogViewerConfig) jaxbContext.createUnmarshaller().unmarshal(xmlInputStream);
		
		// Assertions
		assertNotNull(logViewerConfig);
		LogAccessConfig firstLogAccessConfig = logViewerConfig.getLogAccessConfigs().iterator().next();
		assertEquals("config-with-users", firstLogAccessConfig.getId());
		assertEquals(LogAccessType.LOCAL, firstLogAccessConfig.getType());
		assertEquals("target/test-classes/files", firstLogAccessConfig.getDirectory());
		assertEquals(2, firstLogAccessConfig.getAuthorizedUsers().size());
	}

}
