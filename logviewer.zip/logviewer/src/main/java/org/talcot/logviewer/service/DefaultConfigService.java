package org.talcot.logviewer.service;

import static org.talcot.logviewer.util.Constants.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import net.schmizz.sshj.common.IOUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.talcot.logviewer.bean.LogAccessConfig;
import org.talcot.logviewer.bean.LogViewerConfig;
import org.talcot.logviewer.bean.LogAccessConfig.LogAccessType;
import org.talcot.logviewer.exception.ConfigException;


@Service
public class DefaultConfigService implements ConfigService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultConfigService.class);
	
	private static final String DEFAULT_LOGVIEWER_CONFIG_LOCATION = "classpath:logviewer.xml";
	private static final int DEFAULT_FILE_LIST_MAX_COUNT = 1000;
	private static final boolean DEFAULT_FILE_LIST_BLOCK_EXTERNAL_PATHS = false;
	

	/** All log access configurations loaded from logviewer.xml */
	Set<LogAccessConfig> logAccessConfigs;
	
	/** last time that logviewer.xml was modified */
	long logViewerConfigLastModified;

	/** JAXBContext used to load logviewer.xml content */
	JAXBContext logViewerConfigJaxbContext;

	/** Log viewer main configuration location */
	@Value("${logviewer.config:" + DEFAULT_LOGVIEWER_CONFIG_LOCATION + "}")
	Resource logViewerConfigResource;
	
	/** max file count in screen listing files */
	@Value("${filelist.maxcount:" + DEFAULT_FILE_LIST_MAX_COUNT + "}")
	int fileListMaxCount; 
	
	/** is block external paths enabled */
	@Value("${filelist.blockexternalpaths:" + DEFAULT_FILE_LIST_BLOCK_EXTERNAL_PATHS + "}")
	private boolean fileListBlockExternalPaths;
	
	/** forbidden commands list */
	@Value("${forbidden.commands:" + DEFAULT_FORBIDDEN_COMMANDS + "}")
	String forbiddenCommands = DEFAULT_FORBIDDEN_COMMANDS;
	
	/** default encoding used to read command output */
	@Value("${default.encoding:" + DEFAULT_ENCODING_OPTION + "}")
	String defaultEncoding = DEFAULT_ENCODING_OPTION;


	@Override
	public synchronized Set<LogAccessConfig> getLogAccessConfigs() throws ConfigException {
		
		reloadLogViewerConfigIfNecessary();

		return logAccessConfigs;
	}
	
	@Override
	public synchronized LogAccessConfig getLogAccessConfig(String id) throws ConfigException {
		
		// Search the LogAccessConfig with the param id
		for (LogAccessConfig logAccessConfig : getLogAccessConfigs()) {
			if (logAccessConfig.getId().equals(id)) {
				return logAccessConfig;
			}
		}
		
		// No LogAccessConfig found
		throw new ConfigException("logAccessConfigId " + id + " doesn't correspond to any known log access config");
	}

	@Override
	public int getFileListMaxCount() {
		return fileListMaxCount;
	}

	@Override
	public boolean getFileListBlockExternalPaths() {
		return fileListBlockExternalPaths;
	}

	@Override
	public String getForbiddenCommands() {
		return forbiddenCommands;
	}

	@Override
	public String getDefaultEncoding(String logAccessConfigId) {
		LogAccessConfig logAccessConfig = getLogAccessConfig(logAccessConfigId);
		if (logAccessConfig.getDefaultEncoding() != null) {
			return logAccessConfig.getDefaultEncoding();
		}
		else {
			return defaultEncoding;
		}
	}
	
	/**
	 * Load or Reload the set of LogAccessConfig beans, from log viewer config file
	 */
	synchronized void reloadLogViewerConfigIfNecessary() throws ConfigException {
		
		// Does config file exist ?
		if (!logViewerConfigResource.exists()) {
			throw new ConfigException("The config file " + logViewerConfigResource + " does not exist");
		}
		
		// Should we reload config file ? (because it has been modified since last reload)
		long lastModified;
		try {
			lastModified = logViewerConfigResource.lastModified();
			boolean needReload = (lastModified > this.logViewerConfigLastModified);
			if (!needReload) {
				return;
			}
		} catch (IOException e) {
			throw new ConfigException("Error when trying to access log viewer config file " + logViewerConfigResource, e);
		}
		
		// Load logviewer XML configuration
		InputStream logViewerConfigInputStream = null;
		try {
			logViewerConfigInputStream = logViewerConfigResource.getInputStream();
			Unmarshaller unmarshaller = logViewerConfigJaxbContext.createUnmarshaller();
			LogViewerConfig logViewerConfig = (LogViewerConfig) unmarshaller.unmarshal(logViewerConfigInputStream);
			this.logAccessConfigs = logViewerConfig.getLogAccessConfigs();
		}
		catch (IOException e) {
			throw new ConfigException("I/O error when trying to load log viewer config file " + logViewerConfigResource, e);
		}
		catch (JAXBException e) {
			throw new ConfigException("XML load error when trying to load log viewer config file " + logViewerConfigResource, e);
		}
		finally {
			IOUtils.closeQuietly(logViewerConfigInputStream);
		}
		
		validateConfiguration();
		
		// Update the lastModified date information for config file
		this.logViewerConfigLastModified = lastModified;
	}

	/**
	 * Validate loaded configuration
	 * @throws ConfigException if configuration is invalid
	 */
	synchronized void validateConfiguration() throws ConfigException {
		
		// Case where configuration is empty => config error
		if (this.logAccessConfigs.isEmpty()) {
			throw new ConfigException("log viewer config file " + logViewerConfigResource + " is empty : at least one configuration must be defined");
		}
		
		for (LogAccessConfig logAccessConfig : this.logAccessConfigs) {
			
			if (logAccessConfig.getType() == null) {
				throw new ConfigException("unknown type for log-access-config '" + logAccessConfig.getId() + "'. Valid values are : " + Arrays.asList(LogAccessType.values()));
			}

			switch (logAccessConfig.getType()) {
			case LOCAL:
				if (StringUtils.isEmpty(logAccessConfig.getDirectory())) {
					throw new ConfigException("'directory' attribute must be defined for log-access-config '" + logAccessConfig.getId() + "'");
				}
				File directoryFile = new File(logAccessConfig.getDirectory());
				if (!directoryFile.isAbsolute()) {
					logAccessConfig.setDirectory(directoryFile.getAbsolutePath());
				}
				break;
			case HTTPD:
				if (StringUtils.isEmpty(logAccessConfig.getUrl())) {
					throw new ConfigException("'url' attribute must be defined for log-access-config '" + logAccessConfig.getId() + "'");
				}
				if (!logAccessConfig.getUrl().endsWith("/")) {
					logAccessConfig.setUrl(logAccessConfig.getUrl() + "/");
				}
				break;
			case SSH:
				if (StringUtils.isEmpty(logAccessConfig.getUser())) {
					throw new ConfigException("'user' attribute must be defined for log-access-config '" + logAccessConfig.getId() + "'");
				}
				if (StringUtils.isEmpty(logAccessConfig.getHost())) {
					throw new ConfigException("'host' attribute must be defined for log-access-config '" + logAccessConfig.getId() + "'");
				}
				if (StringUtils.isEmpty(logAccessConfig.getDirectory())) {
					throw new ConfigException("'directory' attribute must be defined for log-access-config '" + logAccessConfig.getId() + "'");
				}
				break;
			default:
				throw new IllegalStateException("unmanaged log access config type : " + logAccessConfig.getType() + "'");
			}
		}
	}
	
	/**
	 * Init the Spring Service
	 */
	@PostConstruct
	public synchronized void init() {
		try {
			logViewerConfigJaxbContext = JAXBContext.newInstance(LogViewerConfig.class);
			reloadLogViewerConfigIfNecessary();
		}
		catch (JAXBException e) {
			LOGGER.error("Error while loading configuration file {}", logViewerConfigResource, e);
		}
		catch (ConfigException e) {
			LOGGER.error("Error while loading configuration file {}", logViewerConfigResource, e);
		}
	}

}
