package org.talcot.logviewer.bean;

public enum DisplayType {
	TABLE,
	RAW;
}
