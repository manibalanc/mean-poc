package org.talcot.logviewer.bean;

/**
 * Operating System Type where commands are run
 */
public enum OsType {
	LINUX,
	AIX,
	WINDOWS
}
