package org.talcot.logviewer.controller;

import java.text.MessageFormat;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.CookieClearingLogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.talcot.logviewer.bean.LogAccessConfig;
import org.talcot.logviewer.exception.AuthorizationException;
import org.talcot.logviewer.service.AuthorizationService;
import org.talcot.logviewer.service.ConfigService;
import org.talcot.logviewer.util.Constants;

@Controller
public class IndexController {

	@Autowired
	private ConfigService configService;

	@Autowired
	private AuthorizationService authorizationService;

	@RequestMapping({ "/", "/logs", "/logs/" })
	public String index(Model model,RedirectAttributes redir) throws AuthorizationException {
		
		System.out.println("Entering IndexController index");
		
		// Get only authorized log access configs
		Authentication authorizedUser = SecurityContextHolder.getContext().getAuthentication();
		System.out.println("authorizedUser::" + authorizedUser);
		Set<LogAccessConfig> allLogAccessConfigs = configService.getLogAccessConfigs();
		Set<LogAccessConfig> authorizedLogAccessConfigs = authorizationService
				.getAuthorizedLogAccessConfigs(allLogAccessConfigs, authorizedUser);

		// If no authorized log access config => show authorization error to
		// client
		if (authorizedLogAccessConfigs.isEmpty()) {
			throw new AuthorizationException("You are not authorized to any log access configuration");
		}

		// Else redirect to first logAccessConfig
		String logAccessConfigId = authorizedLogAccessConfigs.iterator().next().getId();
		String host = authorizedLogAccessConfigs.iterator().next().getHost();
		redir.addFlashAttribute("host", host);
		System.out.println(host+"---"+MessageFormat.format(Constants.REDIRECT_LOGS_LIST_CONTROLLER, logAccessConfigId));
		return MessageFormat.format(Constants.REDIRECT_LOGS_LIST_CONTROLLER, logAccessConfigId);
	}

	@RequestMapping(value = { "/logout"}, method = RequestMethod.POST)
	public String logoutDo(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		SecurityContextHolder.clearContext();
	    CookieClearingLogoutHandler cookieClearingLogoutHandler = new CookieClearingLogoutHandler(AbstractRememberMeServices.SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY);
	    SecurityContextLogoutHandler securityContextLogoutHandler = new SecurityContextLogoutHandler();
	    cookieClearingLogoutHandler.logout(request, response, null);
	    securityContextLogoutHandler.logout(request, response, null);
		session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		for (Cookie cookie : request.getCookies()) {
			cookie.setMaxAge(0);
		}
		System.out.println(SecurityContextHolder.getContext().getAuthentication());
		return "logout";
	}
}
