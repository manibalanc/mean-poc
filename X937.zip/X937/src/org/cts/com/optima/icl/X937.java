package org.cts.com.optima.icl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.thelastcheck.commons.buffer.ByteArray;
import com.thelastcheck.io.x9.ControlTotalsRecordFilter;
import com.thelastcheck.io.x9.X9OutputStreamRecordWriter;
import com.thelastcheck.io.x9.X9Record;
import com.thelastcheck.io.x9.factory.DefaultX9RecordFactoryStrategy;
import com.thelastcheck.io.x9.factory.X9RecordFactory;
import com.thelastcheck.io.x9.factory.X9RecordFactoryStrategy;
import com.thelastcheck.io.x937.records.X937BundleControlRecord;
import com.thelastcheck.io.x937.records.X937BundleHeaderRecord;
import com.thelastcheck.io.x937.records.X937CashLetterControlRecord;
import com.thelastcheck.io.x937.records.X937CashLetterHeaderRecord;
import com.thelastcheck.io.x937.records.X937CheckDetailRecord;
import com.thelastcheck.io.x937.records.X937CreditRecord;
import com.thelastcheck.io.x937.records.X937FileControlRecord;
import com.thelastcheck.io.x937.records.X937FileHeaderRecord;
import com.thelastcheck.io.x937.records.X937ImageViewDataRecord;
import com.thelastcheck.io.x937.records.X937ImageViewDetailRecord;

public class X937 {
	
	public static String padRight(String s, int n) {
	     return String.format("%-" + n + "s", s);  
	}

	public static String padLeft(String s, int n) {
	    return String.format("%" + n + "s", s);  
	}
	
	public static void main(String[] args) throws IOException {
		// Build factory and set the encoding
		X9RecordFactoryStrategy strategy = new DefaultX9RecordFactoryStrategy();
		X9RecordFactory factory = strategy.factory(X9RecordFactoryStrategy.X937_STANDARD_DSTU,
				X9Record.ENCODING_EBCDIC); // X9Record.ENCODING_US_ASCII

		// File Header type 01 record 
		X937FileHeaderRecord headerRecord = (X937FileHeaderRecord) factory.newX9Record(X9Record.TYPE_FILE_HEADER);
		headerRecord.standardLevel("03");
		headerRecord.testFileIndicator("T");
		headerRecord.immediateDestinationRoutingNumber("121000248");
		headerRecord.immediateOriginRoutingNumber("407120004");
		headerRecord.fileCreationDate(new Date());
		headerRecord.fileCreationTime("1530");
		headerRecord.resendIndicator("N");
		headerRecord.immediateDestinationName("Wells Fargo Bank  ");
		headerRecord.immediateOriginName(padLeft(" ", 18)); 
		headerRecord.fileIDModifier("1");
		headerRecord.countryCode("US");
		headerRecord.userField("   ");
		headerRecord.reserved(" ");
		System.out.println(headerRecord.toXml());
		
		// Cash Letter Header type 10 record
		X937CashLetterHeaderRecord cashLetterHeaderRecord = (X937CashLetterHeaderRecord) factory.newX9Record(X9Record.TYPE_CASH_LETTER_HEADER);
		cashLetterHeaderRecord.collectionTypeIndicator("01");
		cashLetterHeaderRecord.destinationRoutingNumber("121000248");
		cashLetterHeaderRecord.ECEInstitutionRoutingNumber("123456789");
		cashLetterHeaderRecord.cashLetterBusinessDate(new Date());
		cashLetterHeaderRecord.cashLetterCreationDate(new Date());
		cashLetterHeaderRecord.cashLetterCreationTime(new Date());
		cashLetterHeaderRecord.cashLetterRecordTypeIndicator("I");
		cashLetterHeaderRecord.cashLetterDocumentationTypeIndicator("G");
		cashLetterHeaderRecord.cashLetterID("20310001");
		cashLetterHeaderRecord.originatorContactName("Mani");
		cashLetterHeaderRecord.originatorContactName("1234567890");
		cashLetterHeaderRecord.fedWorkType("C");
		cashLetterHeaderRecord.userField("  ");
		cashLetterHeaderRecord.reserved(" ");
		System.out.println(cashLetterHeaderRecord.toXml());
		
		// Bundle Header type 20 record
		X937BundleHeaderRecord bundleHeaderRecord = (X937BundleHeaderRecord) factory.newX9Record(X9Record.TYPE_BUNDLE_HEADER);
		bundleHeaderRecord.collectionTypeIndicator("01");
		bundleHeaderRecord.destinationRoutingNumber("121000248");
		bundleHeaderRecord.ECEInstitutionRoutingNumber("123456789");
		bundleHeaderRecord.bundleBusinessDate(new Date());
		bundleHeaderRecord.bundleCreationDate(new Date());
		bundleHeaderRecord.bundleID("0000000001");
		bundleHeaderRecord.bundleSequenceNumber("0001");
		bundleHeaderRecord.cycleNumber("01");
		bundleHeaderRecord.returnLocationRoutingNumber("999999999");
		bundleHeaderRecord.returnLocationRoutingNumber("         ");
		bundleHeaderRecord.userField("     ");
		bundleHeaderRecord.reserved("            ");
		System.out.println(bundleHeaderRecord.toXml());
		
		// Credit type 61 record
		X937CreditRecord creditRecord = (X937CreditRecord) factory.newX9Record(X9Record.TYPE_CREDIT);
		creditRecord.amountOfCredit("0000123450");
		creditRecord.creditCardAccountNumber("123456789");
		creditRecord.processControl("  6586");
		creditRecord.routingNumber("500000377");
		creditRecord.serialNumberAuxiliaryOnUs("               ");
		creditRecord.itemSequenceNumber("000000000100045");
		creditRecord.externalProcessingCode(" ");
		creditRecord.typeOfAccountCode(" ");
		creditRecord.sourceOfWorkCode("3");
		creditRecord.reserved(" ");
		System.out.println(creditRecord.toXml());
		
		// Check Detail type 25 record
		X937CheckDetailRecord checkDetailRecord = (X937CheckDetailRecord) factory.newX9Record(X9Record.TYPE_CHECK_DETAIL);
		checkDetailRecord.auxiliaryOnUs("               ");
		checkDetailRecord.externalProcessingCode(" ");
		checkDetailRecord.payorBankRoutingNumber("12100024");
		checkDetailRecord.payorBankRoutingNumberCheckDigit("8");
		checkDetailRecord.onUs("0000000001/000000042");
		checkDetailRecord.itemAmount("0000123450");
		checkDetailRecord.ECEInstitutionItemSequenceNumber("000000000100045");
		checkDetailRecord.documentationTypeIndicator("G");
		checkDetailRecord.returnAcceptanceIndicator(" ");
		checkDetailRecord.MICRValidIndicator(" ");
		checkDetailRecord.BOFDIndicator("U");
		checkDetailRecord.checkDetailRecordAddendumCount("00");
		checkDetailRecord.archiveTypeIndicator("B");
		System.out.println(checkDetailRecord.toXml());

		//Image View Detail type 50 record
		// Image - Front
		File checkFrontImage = new File("C:\\Users\\272126\\Desktop\\optima\\check\\10000001.jpg");
		X937ImageViewDetailRecord frontImageViewDetailRecord = (X937ImageViewDetailRecord) factory.newX9Record(X9Record.TYPE_IMAGE_VIEW_DETAIL);
		frontImageViewDetailRecord.imageIndicator("1");
		frontImageViewDetailRecord.imageCreatorRoutingNumber("123456789");
		frontImageViewDetailRecord.imageCreatorDate(new Date());
		frontImageViewDetailRecord.imageViewFormatIndicator("00");
		frontImageViewDetailRecord.imageViewCompressionAlgorithmIdentifier("00");
		frontImageViewDetailRecord.imageViewDataSize((int) checkFrontImage.length());
		frontImageViewDetailRecord.viewSideIndicator("0");
		frontImageViewDetailRecord.viewDescriptor("00");
		frontImageViewDetailRecord.digitalSignatureIndicator("0");
		frontImageViewDetailRecord.digitalSignatureMethod("  ");
		frontImageViewDetailRecord.securityKeySize("     ");
		frontImageViewDetailRecord.startOfProtectedData("       ");
		frontImageViewDetailRecord.lengthofProtectedData("       ");
		frontImageViewDetailRecord.imageRecreateIndicator("0");
		frontImageViewDetailRecord.userField("        ");
		frontImageViewDetailRecord.reserved("     ");
		System.out.println(frontImageViewDetailRecord.toXml());
		
		// Image View Data type 52 record
		// Image Data - Front
		X937ImageViewDataRecord frontImageViewDataRecord = (X937ImageViewDataRecord) factory.newX9Record(X9Record.TYPE_IMAGE_VIEW_DATA);
		frontImageViewDataRecord.ECEInstitutionRoutingNumber("123456789");
		frontImageViewDataRecord.bundleBusinessDate(new Date());
		frontImageViewDataRecord.cycleNumber("01");
		frontImageViewDataRecord.ECEInstitutionItemSequenceNumber("000000000100045");
		frontImageViewDataRecord.securityOriginatorName("                ");
		frontImageViewDataRecord.securityAuthenticatorName("               ");
		frontImageViewDataRecord.securityKeyName("                ");
		frontImageViewDataRecord.clippingOrigin("0");
		frontImageViewDataRecord.clippingCoordinateH1("    ");
		frontImageViewDataRecord.clippingCoordinateH2("    ");
		frontImageViewDataRecord.clippingCoordinateV1("    ");
		frontImageViewDataRecord.clippingCoordinateV2("    ");
		frontImageViewDataRecord.lengthOfDigitalSignature();
		frontImageViewDataRecord.imageData(new ByteArray(Files.readAllBytes(checkFrontImage.toPath())));
		frontImageViewDataRecord.lengthOfImageData();
		System.out.println(frontImageViewDataRecord.toXml());

		// Image - Rear
		File checkRearImage = new File("C:\\Users\\272126\\Desktop\\optima\\check\\20000001.jpg");
		X937ImageViewDetailRecord rearImageViewDetailRecord = (X937ImageViewDetailRecord) factory.newX9Record(X9Record.TYPE_IMAGE_VIEW_DETAIL);
		rearImageViewDetailRecord.imageIndicator("1");
		rearImageViewDetailRecord.imageCreatorRoutingNumber("123456789");
		rearImageViewDetailRecord.imageCreatorDate(new Date());
		rearImageViewDetailRecord.imageViewFormatIndicator("00");
		rearImageViewDetailRecord.imageViewCompressionAlgorithmIdentifier("00");
		rearImageViewDetailRecord.imageViewDataSize((int) checkRearImage.length());
		rearImageViewDetailRecord.viewSideIndicator("1");
		rearImageViewDetailRecord.viewDescriptor("00");
		rearImageViewDetailRecord.digitalSignatureIndicator("0");
		rearImageViewDetailRecord.digitalSignatureMethod("  ");
		rearImageViewDetailRecord.securityKeySize("     ");
		rearImageViewDetailRecord.startOfProtectedData("       ");
		rearImageViewDetailRecord.lengthofProtectedData("       ");
		rearImageViewDetailRecord.imageRecreateIndicator("0");
		rearImageViewDetailRecord.userField("        ");
		rearImageViewDetailRecord.reserved("     ");
		System.out.println(rearImageViewDetailRecord.toXml());

		
		
		// Image Data - Rear
		X937ImageViewDataRecord rearImageViewDataRecord = (X937ImageViewDataRecord) factory.newX9Record(X9Record.TYPE_IMAGE_VIEW_DATA);
		rearImageViewDataRecord.ECEInstitutionRoutingNumber("123456789");
		rearImageViewDataRecord.bundleBusinessDate(new Date());
		rearImageViewDataRecord.cycleNumber("01");
		rearImageViewDataRecord.ECEInstitutionItemSequenceNumber("000000000100045");
		rearImageViewDataRecord.securityOriginatorName("                ");
		rearImageViewDataRecord.securityAuthenticatorName("               ");
		rearImageViewDataRecord.securityKeyName("                ");
		rearImageViewDataRecord.clippingOrigin("0");
		rearImageViewDataRecord.clippingCoordinateH1("    ");
		rearImageViewDataRecord.clippingCoordinateH2("    ");
		rearImageViewDataRecord.clippingCoordinateV1("    ");
		rearImageViewDataRecord.clippingCoordinateV2("    ");
		rearImageViewDataRecord.lengthOfDigitalSignature();
		rearImageViewDataRecord.imageData(new ByteArray(Files.readAllBytes(checkRearImage.toPath())));
		rearImageViewDataRecord.lengthOfImageData();
		System.out.println(rearImageViewDataRecord.toXml());

		// Bundle Control type 70 record
		X937BundleControlRecord bundleControlRecord = (X937BundleControlRecord) factory.newX9Record(X9Record.TYPE_BUNDLE_CONTROL);
		bundleControlRecord.itemsWithinBundleCount("1");
		bundleControlRecord.bundleTotalAmount("0000123450");
		bundleControlRecord.MICRValidTotalAmount("            ");
		bundleControlRecord.imagesWithinBundleCount("2");
		bundleControlRecord.userField("                    ");
		bundleControlRecord.reserved("                         ");
		System.out.println(bundleControlRecord.toXml());
		
		// Cash Letter Control type 90 record
		X937CashLetterControlRecord cashLetterControlRecord = (X937CashLetterControlRecord) factory.newX9Record(X9Record.TYPE_CASH_LETTER_CONTROL);
		cashLetterControlRecord.bundleCount("1");
		cashLetterControlRecord.itemsWithinCashletterCount("1");
		cashLetterControlRecord.cashLetterTotalAmount("0000123450");
		cashLetterControlRecord.imagesWithinCashLetterCount("2");
		cashLetterControlRecord.ECEInstitutionName("Cognizant");
		cashLetterControlRecord.settlementDate("       ");
		cashLetterControlRecord.reserved("               ");
		System.out.println(cashLetterControlRecord.toXml());

		// File Control type 99 record
		X937FileControlRecord fileControlRecord = (X937FileControlRecord) factory.newX9Record(X9Record.TYPE_FILE_CONTROL);
		fileControlRecord.cashLetterCount("000001");
		fileControlRecord.totalRecordCount("1");
		fileControlRecord.totalItemCount("1");
		fileControlRecord.fileTotalAmount("0000123450");
		fileControlRecord.immediateOriginContactName("Mani");
		fileControlRecord.immediateOriginContactPhoneNumber("1234567890");
		fileControlRecord.reserved("                ");
		System.out.println(fileControlRecord.toXml());
		
		// creates the X9 file
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		OutputStream os = new FileOutputStream("C:\\Users\\272126\\Desktop\\optima\\icl\\output\\WEED_"+timeStamp+".937");
		BufferedOutputStream bos = new BufferedOutputStream(os, 65536);
		X9OutputStreamRecordWriter out = new X9OutputStreamRecordWriter(bos);
		out.addFilter(new ControlTotalsRecordFilter());
		out.write(headerRecord);
		out.write(cashLetterHeaderRecord);
		out.write(bundleHeaderRecord);
		out.write(creditRecord);
		out.write(checkDetailRecord);
		out.write(frontImageViewDetailRecord);
		out.write(frontImageViewDataRecord);
		out.write(rearImageViewDetailRecord);
		out.write(rearImageViewDataRecord);
		out.write(bundleControlRecord);
		out.write(cashLetterControlRecord);
		out.write(fileControlRecord);
		out.close();
	}
}
